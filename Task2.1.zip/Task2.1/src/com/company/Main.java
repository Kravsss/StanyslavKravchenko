package com.company;

public class Main {

    public static void main(String[] args) {
        int x = (int) (Math.random() * 20);
        System.out.println(" 1 value = " + x);
        int y = (int) (Math.random() * 20);
        System.out.println(" 2 value = " + y);
        int z = (int) (Math.random() * 20);
        System.out.println(" 3 value " + z);
        x = (x < y && x < z) ? x : ((y < z) ? y : z);
        System.out.println(" Min Value : " + x);
    }

}