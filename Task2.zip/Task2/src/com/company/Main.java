package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double a, b, c;
        System.out.println("Enter a side of the triangle : ");
        a = scanner.nextDouble();
        System.out.println("Enter b side of the triangle : ");
        b = scanner.nextDouble();
        System.out.println("Enter c side of the triangle : ");
        c = scanner.nextDouble();
        double p = (a + b + c) / 2;
        System.out.println(p);
        double s = Math.sqrt(p * (p - a) * (p - b) * (p - c));
        System.out.println(s);


    }
}
