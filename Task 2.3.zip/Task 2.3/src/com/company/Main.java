package com.company;

public class Main {

    public static void main(String[] args) {
        int value = (int) (Math.random() * 20);
        System.out.println(" Random Value : " + value);
        if (value % 2 == 0) {
            System.out.println(" value : " + value + " paired");
        } else {
            System.out.println(" value : " + value + " unpeired ");
        }

    }
}
